/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ModelView;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author abish
 */
public class Server {

    /**
     * @param args the command line arguments
     */
    
    private final ServerSocket serverSocket;
    
    public Server(ServerSocket serverSocket){
        this.serverSocket = serverSocket;
    }
    
    public void empezarServer(){
        
        try{
            while(!serverSocket.isClosed()){
                Socket socket = serverSocket.accept();
                ManejadorCliente manejadorCliente = new ManejadorCliente(socket);    
                Thread thread = new Thread(manejadorCliente);
                thread.start();
            }
        }catch(IOException e){
            cerrarServerSocket();        
    }
    }
    
    public void cerrarServerSocket(){
        try{
            if(serverSocket != null){
                serverSocket.close();
            }
        }catch(IOException e){     
    }
    }
}
