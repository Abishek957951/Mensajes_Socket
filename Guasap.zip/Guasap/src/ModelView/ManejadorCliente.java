/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ModelView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;

/**
 *
 * @author abish
 */
public class ManejadorCliente implements Runnable{
    
    public static ArrayList<ManejadorCliente> manejadorClientes = new ArrayList<>();
    private Socket socket;
    private BufferedReader bufferedReader;
    private BufferedWriter bufferedWriter;
    private String nomUsuario;
    
    public ManejadorCliente(Socket socket){
        try{
            this.socket = socket;
            this.bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            this.bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.nomUsuario = bufferedReader.readLine();
            manejadorClientes.add(this);
            mostrarMensaje("SERVER: " + nomUsuario + "entro al chat");
        }catch (IOException e){
            cerrarTodo(socket, bufferedReader, bufferedWriter);
        }
    }
    
    @Override
    public void run() {
        String mensajeCliente;  
        while(socket.isConnected()) {
            try{
                mensajeCliente = bufferedReader.readLine();
                mostrarMensaje(mensajeCliente);
                System.out.println(mensajeCliente);
            }catch(IOException e){
            cerrarTodo(socket, bufferedReader, bufferedWriter);
            break;
            }   
        }   
    }
    
    public void mostrarMensaje(String mensaje){
        for(ManejadorCliente manejadorCliente : manejadorClientes ){
            try {
                if(!manejadorCliente.nomUsuario.equalsIgnoreCase(nomUsuario)){
                    manejadorCliente.bufferedWriter.write(mensaje);
                    manejadorCliente.bufferedWriter.newLine();
                    manejadorCliente.bufferedWriter.flush();
                    System.out.println(mensaje);
                }
            }catch(IOException e){
                cerrarTodo(socket, bufferedReader, bufferedWriter);
            }
        }
    }
    
    public void removerManejadorCliente(){
        manejadorClientes.remove(this);
        mostrarMensaje("SERVER: " + nomUsuario + "se fue del chat");
    }
    
    public void cerrarTodo(Socket socket, BufferedReader bufferedReader, BufferedWriter bufferedWriter){
        removerManejadorCliente();
        try{
            if(bufferedReader != null){
                bufferedReader.close();
            }
            if(bufferedWriter != null){
                bufferedWriter.close();
            }
            if(socket != null){
                socket.close();
            }
        }
        catch(IOException e){
            e.printStackTrace();
        }   
    }  
}
