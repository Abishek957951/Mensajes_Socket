/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ModelView;

/**
 *
 * @author abish
 */

import View.Enlace;
import View.Pantalla;
import static View.Pantalla.instancia;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Guasap {
    
    public static Enlace enlace = new Enlace();
    static Pantalla pantalla = new Pantalla();
    static Cliente cliente = null;
    
    public static void main(String[] args) throws IOException{
        enlace.setVisible(true);
        enlace.setLocation(400,50);
        ServerSocket serverSocket = new ServerSocket(5050);
        Server server = new Server(serverSocket);
        server.empezarServer();
    }
    
//Funciones de operaciones de abrir y cerrar los formularios
    public static void MostrarInicio() {
        enlace.setVisible(true);
        enlace.setLocation(350,50);
    }
    public static void CerrarInicio() {
        enlace.setVisible(false);
    }
    public static void MostrarPantalla() {
        pantalla.setVisible(true);
        pantalla.setLocation(350,50);
    }
    public static void CerrarPantalla() {
        pantalla.setVisible(false);
    }
    
    
    public static void crearCliente(Socket socket, String nomUsuario){
        cliente = new Cliente(socket, nomUsuario);
    }   
    public static void mandarMensajes(String mensaje){
        cliente.mandarMensaje(mensaje);
    }   
    public static void waitMensajes(){
        cliente.esperarMensajes();
    }
    public static void recibirMensajes(){
        instancia.agregar_labels(cliente.ponerMensaje()); 
        System.out.println("Mnesaje se envia pero no se dibuja");
    }
    
    
    
    
    
    
    
    
    
}
