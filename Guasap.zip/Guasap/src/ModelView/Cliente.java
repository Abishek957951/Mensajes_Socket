/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ModelView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

/**
 *
 * @author abish
 */
public class Cliente {
    
    private Socket socket;
    private BufferedReader bufferedReader;
    private BufferedWriter bufferedWriter;
    private String nomUsuario;
    private String mensajeChat;
    
    public Cliente(Socket socket,String nomUsuario){
        try{
            this.socket = socket;
            this.bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            this.bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.nomUsuario = nomUsuario;
        }catch(IOException e){
            cerrarTodo(socket, bufferedReader, bufferedWriter);
        }
    }
    public void mandarMensaje(String mensaje){
        try{
                bufferedWriter.write(nomUsuario + ": " + mensaje);
                bufferedWriter.newLine();
                bufferedWriter.flush();
                System.out.println("Mensaje Mandado");
        }catch(IOException e){
            cerrarTodo(socket, bufferedReader, bufferedWriter);
        }
    }
    
    public void esperarMensajes(){
        new Thread(new Runnable(){
            @Override
            public void run(){
                String mensajePrueba;     
                while(socket.isConnected()){
                    try{
                        mensajePrueba = bufferedReader.readLine();
                        mensajeChat = mensajePrueba;
                        System.out.println("recibi un mensaje");
                        Guasap.recibirMensajes();
                    }catch(IOException e){
                        cerrarTodo(socket, bufferedReader, bufferedWriter);
                    }
                }
            }
        }).start();
    }
    
    public void cerrarTodo(Socket socket, BufferedReader bufferedReader, BufferedWriter bufferedWriter){
        try{
            if(bufferedReader != null){
                bufferedReader.close();
            }
            if(bufferedWriter != null){
                bufferedWriter.close();
            }
            if(socket != null){
                socket.close();
            }
        }
        catch(IOException e){
            e.printStackTrace();
        }       
    }
    
    public String ponerMensaje(){
        String mensaje = null;
        if(mensajeChat != null){
        mensaje = mensajeChat;
        }
        return mensaje;
    }
}
